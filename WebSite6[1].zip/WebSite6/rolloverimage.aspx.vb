﻿
Partial Class upload1
    Inherits System.Web.UI.Page

    'Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    If Not FileUpload1.HasFile Then
    '        Label1.Text = "You have not uploaded a file."
    '    ElseIf CheckExtension(FileUpload1.FileName) = False Then
    '        Label1.Text = "Only .gifs, and .jpgs, please."
    '    Else
    '        ImageButton1.Visible = True
    '        Try
    '            FileUpload1.SaveAs(Server.MapPath("~/images/") _
    '            & FileUpload1.FileName)
    '            Label1.Text = "Thumbnail of: " & FileUpload1.FileName
    '            ImageButton1.ImageUrl = "thumbnailer.ashx?file=" _
    '            & Server.UrlEncode(FileUpload1.FileName)
    '        Catch exc As Exception
    '            Label1.Text = "There was a problem: " & exc.Message
    '        End Try
    '    End If
    'End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Image1.Attributes.Add("onmouseover", _
            "this.src='Images/cancel1.gif'")
            Image1.Attributes.Add("onmouseout", _
            "this.src='Images/cancel.gif'")
            ImageButton1.Attributes.Add("onmouseover", _
            "this.src='Images/cancel1.gif'")
            ImageButton1.Attributes.Add("onmouseout", _
            "this.src='Images/cancel.gif'")
        End If
    End Sub
End Class
