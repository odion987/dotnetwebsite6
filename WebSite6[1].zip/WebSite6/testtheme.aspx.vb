﻿
Partial Class testtheme
    Inherits System.Web.UI.Page

End Class
