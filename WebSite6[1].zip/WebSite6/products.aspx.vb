﻿
Partial Class products
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
    
    End Sub



    Protected Sub ListView1_ItemCreated _
(ByVal sender As Object, ByVal e As System.Web.UI.WebControls. _
ListViewItemEventArgs) Handles ListView1.ItemCreated
        Dim li As ListViewItem
        Dim ddl As DropDownList
        If e.Item.ItemType = ListViewItemType.InsertItem Then
            li = e.Item
            ddl = li.FindControl("SupplierIDDDL")
            If Not ddl Is Nothing Then
                Dim dc As New NWDataClassesDataContext
                Dim q = From c In dc.details _
                Select txt = c.names, valu = c.address _
                Order By txt
                Dim itm As ListItem
                ddl.Items.Clear()
                For Each i In q
                    itm = New ListItem
                    itm.Text = i.txt
                    itm.Value = i.valu
                    ddl.Items.Add(itm)
                Next
            End If
        End If
    End Sub

    Protected Sub LinqDataSource1_Deleting(sender As Object, e As LinqDataSourceDeleteEventArgs) Handles LinqDataSource1.Deleting

    End Sub
End Class
