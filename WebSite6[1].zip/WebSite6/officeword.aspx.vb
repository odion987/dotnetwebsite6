﻿
Partial Class officeword
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Response.Buffer = True
            Response.Clear()
            Response.ClearContent()
            Response.ClearHeaders()
            Response.ContentType = "application/msword"
            Response.AddHeader("Content-Disposition", _
"attachment;filename=waec_form.doc")
            Response.WriteFile(Server.MapPath _
            ("~/waec_form.doc"))
            Response.End()
        Catch exc As Exception
            Response.Write(exc.Message)
        End Try
    End Sub
End Class
