﻿
Partial Class datalookup
    Inherits System.Web.UI.Page

    
    
End Class
