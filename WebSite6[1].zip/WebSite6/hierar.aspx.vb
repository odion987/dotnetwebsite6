﻿
Partial Class hierar
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim dc As New NWDataClassesDataContext
        Dim q = From c In dc.details
        'p In dc.Products _
        'Where c.CategoryID = p.CategoryID _
        'Group p By c.CategoryName Into Group _
        'Select New With _
        '{.cgname = CategoryName, _
        '.prdcts = Group}
        gvCategories.DataSource = q
        gvCategories.DataBind()
    End Sub
End Class
