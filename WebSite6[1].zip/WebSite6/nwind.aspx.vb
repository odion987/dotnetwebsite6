﻿
Partial Class nwind
    Inherits System.Web.UI.Page

End Class
