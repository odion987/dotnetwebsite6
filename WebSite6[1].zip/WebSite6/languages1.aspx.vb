﻿
Partial Class languages1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim q = _
From c In _
System.Globalization.CultureInfo.GetCultures(2) _
Order By c.EnglishName _
Order By c.TwoLetterISOLanguageName Distinct _
Group c By c.TwoLetterISOLanguageName Into Group _
Select New With _
{.ISO = TwoLetterISOLanguageName, .culture = Group}
        dlLetters.DataSource = q
        dlLetters.DataBind()
    End Sub
End Class
