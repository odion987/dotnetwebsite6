This project is an part output of asp.net for beginners vb.net (visual studios 2008)

The project is helpful to save stress for those who want to go through the manual

Users can get started by scrupulously going through the ebook - asp.net for beginners

users can google through to find their way

I maintain  and contribute to the project