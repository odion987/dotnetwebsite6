﻿
Partial Class menu
    Inherits System.Web.UI.Page

End Class
