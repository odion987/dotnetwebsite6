﻿
Partial Class exclaim
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        BindData()
    End Sub


    Protected Sub BindData()
        Dim dc As New NWDataClassesDataContext
        Dim q = From p In dc.details
        GridView1.DataSource = q
        GridView1.DataBind()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dc As New NWDataClassesDataContext
        Dim q = From p In dc.details _
        Where p.names.StartsWith("o") _
        Select p
        For Each prod In q

            'prod.names = prod.names.ToExclaim()
            prod.names = Replace(prod.names, "!", "")
        Next
dc.SubmitChanges()
BindData()
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim dc As New NWDataClassesDataContext
        Dim prdcts = dc.details
        Dim prod = New detail
        prod.names = "udochika"
        prod.address = "oreyo, igbogbo, ikorodu, lagos"
        'prod.QuantityPerUnit = "8 per box"
        'prod.UnitPrice = 5
        'prod.SupplierID = 2
        'prod.CategoryID = 1
        'prod.UnitsInStock = 5
        'prod.ReorderLevel = 1
        prdcts.InsertOnSubmit(prod)
        dc.SubmitChanges()
        BindData()
    End Sub
End Class
