﻿
Partial Class useimage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Image1.ImageUrl = "generateimage.aspx"
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Image1.ImageUrl = "generateimage.aspx?text=" _
& Server.UrlEncode(TextBox1.Text)
    End Sub
End Class
