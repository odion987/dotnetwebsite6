﻿
Partial Class lcl
    Inherits System.Web.UI.Page

End Class
