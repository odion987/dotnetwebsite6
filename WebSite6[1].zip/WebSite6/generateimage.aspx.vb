﻿
Partial Class generateimage
    Inherits System.Web.UI.Page

End Class
