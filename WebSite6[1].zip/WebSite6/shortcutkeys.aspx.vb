﻿
Partial Class shortcutkeys
    Inherits System.Web.UI.Page

End Class
