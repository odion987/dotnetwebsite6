﻿
Partial Class mdtlpg
    Inherits System.Web.UI.Page

End Class
