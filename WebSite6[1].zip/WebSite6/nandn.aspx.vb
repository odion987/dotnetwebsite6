﻿
Partial Class nandn
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim root As XElement = _
XElement.Load(Server.MapPath _
("~/App_Data/niecesandnephews.xml"))
        Dim q = From k In root.Descendants _
        Where (k.Element("father") = "Ron" Or _
        k.Element("father") = "Stan") _
        Where k.Element("fname").Attribute("gender") = "f" _
        Select First_Name = k.Element("fname").Value, _
        Father = k.Element("father").Value _
        Order By First_Name
        GridView1.DataSource = q
        GridView1.DataBind()
    End Sub
End Class
