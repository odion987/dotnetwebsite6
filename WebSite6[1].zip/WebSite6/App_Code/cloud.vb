﻿

Imports System.Web : Imports System.Linq
Imports System.Web.Services
Imports System.Web.Services.Protocols


<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://kencox.ca/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
Public Class cloud
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function CloudList _
(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim autoCompleteWordList As String()
        autoCompleteWordList = CType(Context.Cache _
        ("autoCompleteWordList"), String())
        If autoCompleteWordList Is Nothing Then
            autoCompleteWordList = System.IO.File.ReadAllLines _
            (Server.MapPath("~/App_Data/cloudtags.txt"))
            Context.Cache.Insert("autoCompleteWordList", autoCompleteWordList)
        End If
        Dim strquery = From wrd In autoCompleteWordList _
        Where wrd.StartsWith(prefixText, _
        StringComparison.CurrentCultureIgnoreCase) _
        Take (count) _
        Order By wrd
        Return strquery.ToArray()
    End Function
End Class