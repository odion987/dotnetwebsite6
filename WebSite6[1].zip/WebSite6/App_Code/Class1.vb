﻿Imports Microsoft.VisualBasic

Public Class Class1
    Public Class KinFolk
        Private _fname As String
        Private _gender As String
        Private _father As String
        Public Property FName() As String
            Get
                Return _fname
            End Get
            Set(ByVal value As String)
                _fname = value
            End Set
        End Property
        Public Property Gender() As String
            Get
                Return _gender
            End Get
            Set(ByVal value As String)
                _gender = value
            End Set
        End Property
        Public Property Father() As String
            Get
                Return _father
            End Get
            Set(ByVal value As String)
                _father = value
            End Set
        End Property
    End Class
End Class
