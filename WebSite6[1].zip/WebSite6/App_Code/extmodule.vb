﻿Imports Microsoft.VisualBasic
Imports System.Runtime.CompilerServices
Public Module Extns
    <Extension()> _
    Function ToExclaim(ByVal s As String) As String
        Return s & "!!"
    End Function
End Module