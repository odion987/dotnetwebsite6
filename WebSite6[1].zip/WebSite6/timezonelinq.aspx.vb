﻿
Partial Class timezonelinq
    Inherits System.Web.UI.Page
    'Dim q = From tz In System.TimeZoneInfo.GetSystemTimeZones

    'Dim q = From tz As TimeZoneInfo _
    'In System.TimeZoneInfo.GetSystemTimeZones()
    ' Dim q = From f In System.Drawing.FontFamily.Families
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'For Each tz As TimeZoneInfo In q
        ' For Each tz In q
        'Response.Write(tz.DisplayName & "<br />")
        'Next
        ' GridView1.DataSource = q
        ' GridView1.DataBind()

        'For Each fnt In q
        'Response.Write(fnt.Name & "<br />")
        'Next
        'GridView1.DataSource = q
        ' GridView1.DataBind()
        '        Dim q = From p In _
        'System.Diagnostics.Process.GetProcesses() _
        'Select p.Id, p.ProcessName, p.PrivateMemorySize64 _
        'Where PrivateMemorySize64 > 1000000
        '        GridView1.DataSource = q
        '        GridView1.DataBind()


        '        Dim q = From sv As String In Request.ServerVariables _
        'Select sv _
        'Where sv Like "*SERVER*"

        '        Dim q = From sv As String In Request.ServerVariables _
        'Select sv _
        'Where sv Like "SERVER*"

        '        Dim q = From sv As String In Request.ServerVariables _
        'Select sv _
        'Where sv Like "*SERVER"

        'GridView1.DataSource = q
        'GridView1.DataBind()



        'Dim dc As New NWDataClassesDataContext
        'Dim q = From p In dc.details _
        'Select p _
        'Where p.address.Contains("ibadan")

        'GridView1.DataSource = q
        'GridView1.DataBind()


        '        Dim names As String() = _
        '{"Elaine", "Brenda", "Julie", "Jaclyn"}
        '        Dim q = _
        '        From s In names _
        '        Where _
        '        s.StartsWith("j", _
        '        StringComparison.CurrentCultureIgnoreCase) _
        '        Or _
        '                s.EndsWith("e", _
        '                StringComparison.CurrentCultureIgnoreCase)
        '        BulletedList1.DataSource = q
        '        BulletedList1.DataBind()




        'Dim dc As New NWDataClassesDataContext
        'Dim q = From p In dc.details _
        'Select p.detailsid, p.names, p.address _
        'Where address = "ibadan"
        'GridView1.DataSource = q
        'GridView1.DataBind()

        '        Dim cinfo As New System.Globalization.CultureInfo("en-CA")
        '        Dim dt(2) As Date
        '        dt(0) = Date.Parse("December 24, 2007", cinfo)
        '        dt(1) = Date.Parse("May 22, 2008", cinfo)
        '        dt(2) = Date.Parse("February 10, 2008", cinfo)
        '        Dim q = From d In dt _
        'Where d > #1/13/2008# _
        'Select d.ToLongDateString
        '        CheckBoxList1.DataSource = q
        '        CheckBoxList1.DataBind()

        
        '        Dim cinfo As New System.Globalization.CultureInfo("en-CA")
        '        Dim dt(2) As Date
        '        Dim firstdt As Date = Date.Parse("october 1, 1960", cinfo)
        '        'dt(1) = Date.Parse("May 22, 2008", cinfo)
        '        Dim secondt As Date = Date.Parse("october 1, 2016", cinfo)
        '        '        Dim q = From d In dt _
        '        'Where d > #1/13/2008# _
        '        'Select d.ToLongDateString
        '        'CheckBoxList1.DataSource = q
        '        'CheckBoxList1.DataBind()

        '        'For dt As Date = #1/10/2008# To #1/10/2008#
        'For firstdt to secondt

        '        Next


        Try
            Dim q = From f In New System.IO.DirectoryInfo _
            (Server.MapPath("~")).GetFiles() _
            Select f _
            Where f.Extension = ".aspx"
            Label1.Text = "ASPX count: " & q.Count().ToString()
            GridView1.DataSource = q
            GridView1.DataBind()
        Catch ex As Exception
            Label1.Text = "Not allowed to do that!"
        End Try



    End Sub
End Class
