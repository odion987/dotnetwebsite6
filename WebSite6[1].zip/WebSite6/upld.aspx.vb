﻿
Partial Class upld
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Not FileUpload1.HasFile Then
            Label1.Text = "You have not uploaded a file."
        ElseIf CheckExtension(FileUpload1.FileName) = False Then
            Label1.Text = "Only .gifs, and .jpgs, please."
        Else
            ImageButton1.Visible = True
            Try
                FileUpload1.SaveAs(Server.MapPath("~/Images/") _
                & FileUpload1.FileName)
                Label1.Text = "Thumbnail of: " & FileUpload1.FileName
                ImageButton1.ImageUrl = "thumbnailer.ashx?file=" _
                & Server.UrlEncode(FileUpload1.FileName)
            Catch exc As Exception
                Label1.Text = "There was a problem: " & exc.Message
            End Try
        End If
    End Sub
    Function CheckExtension(ByVal strFilename As String) As Boolean
        Dim strExt As String = _
        strFilename.Substring(strFilename.LastIndexOf(".")).ToLower()
        Return (strExt = ".jpg") Or (strExt = ".gif")
    End Function
End Class
