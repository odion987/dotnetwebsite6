﻿
Partial Class timedisplay
    Inherits System.Web.UI.Page

End Class
