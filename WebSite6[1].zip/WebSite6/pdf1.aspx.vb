﻿
Partial Class pdf1
    Inherits System.Web.UI.Page

End Class
