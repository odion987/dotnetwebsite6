﻿
Partial Class problemcodedebug
    Inherits System.Web.UI.Page

End Class
