﻿
Partial Class slavepage
    Inherits System.Web.UI.Page

End Class
