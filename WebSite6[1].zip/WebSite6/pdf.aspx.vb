﻿
Partial Class pdf
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Response.Buffer = True
            Response.Clear()
            Response.ClearContent()
            Response.ClearHeaders()
            Response.ContentType = "application/pdf"
            Response.AddHeader("Content-Disposition", _
            "attachment;filename=es17_E.pdf")
            Response.WriteFile(Server.MapPath _
            ("~/es17_E.pdf"))
            Response.End()
        Catch exc As Exception
            Response.Write(exc.Message)
        End Try
    End Sub
End Class
