vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Jan 2017 22:07:46 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|02 Jan 2017 22:07:46 -0000
vti_filesize:IR|80
vti_backlinkinfo:VX|
