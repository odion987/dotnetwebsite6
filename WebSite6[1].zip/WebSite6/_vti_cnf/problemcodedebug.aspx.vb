vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Dec 2016 16:32:57 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|15 Dec 2016 16:32:57 -0000
vti_filesize:IR|83
vti_backlinkinfo:VX|
