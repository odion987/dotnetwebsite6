﻿
Partial Class xmldatasource
    Inherits System.Web.UI.Page

End Class
