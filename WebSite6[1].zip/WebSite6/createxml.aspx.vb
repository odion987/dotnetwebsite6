﻿Imports Class1

Partial Class createxml
    Inherits System.Web.UI.Page
    Public Function CreateData() As List(Of KinFolk)
        Dim nn As New List(Of KinFolk)
        nn.Add(New KinFolk With {.FName = "Dave", .Father = "Ron", .Gender = "m"})
        nn.Add(New KinFolk With {.FName = "Karen", .Father = "Ron", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Amy", .Father = "Mike", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Meghann", .Father = "Mike", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Holly", .Father = "Mike", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Kurtis", .Father = "Paul", .Gender = "m"})
        nn.Add(New KinFolk With {.FName = "Rachel", .Father = "Paul", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Elaine", .Father = "Stan", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Brenda", .Father = "Stan", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Julie", .Father = "Stan", .Gender = "f"})
        nn.Add(New KinFolk With {.FName = "Jaclyn", .Father = "Stan", .Gender = "f"})
        Return nn
    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim nn = CreateData()
        Dim kfdoc As New XDocument(New XDeclaration("1.0", Nothing, Nothing))
        kfdoc.Add(New XComment("LINQ to XML Generated File"))
        Dim kfrootelement As New XElement("kinfolk")
        Dim kfitem As XElement
        Dim kffirstname As XElement
        Dim kffather As XElement
        Dim kfgender As XAttribute
        For Each n In nn
            kfitem = New XElement("kin")
            kffirstname = New XElement("fname", n.FName)
            kfgender = New XAttribute("gender", n.Gender)
            kffirstname.Add(kfgender)
            kfitem.Add(kffirstname)
            kffather = New XElement("father", n.Father)
            kfitem.Add(kffather)
            kfrootelement.Add(kfitem)
        Next
        kfdoc.Add(kfrootelement)
        Try
            kfdoc.Save(Server.MapPath("~/App_Data/niecesandnephews.xml"))
            Label1.Text = "File written"
        Catch exc As Exception
            Label1.Text = "Problem: " & exc.Message
        End Try
    End Sub
End Class
